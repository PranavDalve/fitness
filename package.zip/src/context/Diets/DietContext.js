import { createContext } from "react";
const DietContext = createContext();
export default DietContext;