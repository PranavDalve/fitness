import React, { useContext, useState , useEffect } from 'react'
import DevContext from '../../context/developers/DevContext'
import './AddDevProf.css'
import { useNavigate } from 'react-router-dom';

const AddProf = (props) => {

    const navigate = useNavigate();
    
    useEffect(() => {
        if (localStorage.getItem('authtoken')) {
        }
        else {
          navigate('/login')
        }
      }, [])
    
    const context = useContext(DevContext);
    const { adddiet } = context;
    const [Diet, SetDiet] = useState({ name: "", email: "", role: "", contactNum: "", description: ""});
    const handleclick = (e) => {
        e.preventDefault();
        adddiet(Diet.name, Diet.email, Diet.role, Diet.contactNum, Dev.description);
        SetDiet({ name: "", email: "", role: "", contactNum: "", description: "" })
        props.showAlert("Added successfully", "success");
    }
    const onchange = (e) => {
        SetDiet({ ...Diet, [e.target.name]: e.target.value })
    }
    // add the developer
    return (
        <div>
            <div className='my-3 f'>
                <h1 className='namee'>Add Your Developer Profile</h1>
                <form className='my-3 f'>
                    <div className="my-3">
                        <label htmlFor="name" className="form-label">Name</label>
                        <input type="text" className="form-control" id="name" name='name' aria-describedby="emailHelp" value={Dev.name} onChange={onchange} minLength={5} required />
                    </div>
                    <div className="my-3">
                        <label htmlFor="email" className="form-label">Email</label>
                        <input type="email" className="form-control" id="email" name='email' aria-describedby="emailHelp" value={Dev.email} onChange={onchange} minLength={5} required />
                    </div>
                    <div className="my-3">
                        <label htmlFor="role" className="form-label">role</label>
                        <input type="text" className="form-control" id="role" name='role' value={Dev.role} onChange={onchange} minLength={5} required />
                    </div>
                    <div className="my-3">
                        <label htmlFor="contactNum" className="form-label">contactNum</label>
                        <input type="text" className="form-control" id="contactNum" name='contactNum' value={Dev.contactNum} onChange={onchange} minLength={5} required />
                    </div>
                    <div className="my-3">
                        <label htmlFor="contactNum" className="form-label">description</label>
                        <input type="text" className="form-control" id="description" name='description' value={Dev.description} onChange={onchange} minLength={5} required />
                    </div>
                    {/* <button onClick={handleclick},>Add My Developer Profile</button> */}
                    <button type="button" onClick={handleclick} class="btn btn-outline-success">Add My Developer Profile</button>

                </form>
            </div>
        </div>
    )
}

export default AddProf