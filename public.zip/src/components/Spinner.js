import React from 'react'
import loading from './loading.gif'
import './spinner.css'
const Spinner = () => {
    return (
        <div className="text-center hello">
            <img className="my-3" src={loading} alt="loading" />
        </div>
    )
}

export default Spinner