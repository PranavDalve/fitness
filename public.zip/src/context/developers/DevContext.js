import { createContext } from "react";
const DevContext = createContext();
export default DevContext;